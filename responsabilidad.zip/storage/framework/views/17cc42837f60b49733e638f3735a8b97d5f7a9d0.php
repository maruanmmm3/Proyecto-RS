

<?php $__env->startSection('contenido'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.grupo')->html();
} elseif ($_instance->childHasBeenRendered('ver4gyQ')) {
    $componentId = $_instance->getRenderedChildComponentId('ver4gyQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('ver4gyQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ver4gyQ');
} else {
    $response = \Livewire\Livewire::mount('admin.grupo');
    $html = $response->html();
    $_instance->logRenderedChild('ver4gyQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/equipos/index.blade.php ENDPATH**/ ?>