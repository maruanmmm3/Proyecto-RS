<div class="card">
    <div class="card-body">

        <?php echo Form::open($promocion,['route' => 'admin.carreras.store',$promocion]); ?>

            <div class="form-group">
                <?php echo Form::label('nombre', 'Nombre:'); ?>

                <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre de la Carrera']); ?>


                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>


            <div class="form-group">
                <?php echo Form::text('promocion_id',$promocion->id, ['class' => 'form-control']); ?>


                <?php $__errorArgs = ['promocion_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
           
            

            <?php echo Form::submit('Crear Carrera',['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>

        <?php echo e($promocion->id); ?>


    </div>
</div><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/carreras/edit.blade.php ENDPATH**/ ?>