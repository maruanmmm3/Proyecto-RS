

<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="col">
                    <?php echo Form::open(['route' => 'admin.sembrandos.creando']); ?>

                    <div class="form-group">
                        <b><?php echo Form::label('SEMBRANDO VIDAS'); ?></b>
                        <div class="col-md-12">
                            <?php echo Form::label('year', 'Año:'); ?>

                            <?php echo Form::text('year', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el año  del Proyecto']); ?>

                            <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mt-3">
                            <?php echo Form::label('arbol', 'Arboles:'); ?>

                            <?php echo Form::text('arbol', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la cantidad de arboles']); ?>

                            <?php $__errorArgs = ['arbol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <br>
                    
                        <b><?php echo Form::label('BENEFICIADOS'); ?></b>
                        <div class="col-md-12">
                            <?php echo Form::label('hombre', 'Varones:'); ?>

                            <?php echo Form::text('hombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la cantidad de varones']); ?>

                            <?php $__errorArgs = ['hombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <?php echo Form::label('mujer', 'Mujeres:'); ?>

                            <?php echo Form::text('mujer', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la cantidad de mujeres']); ?>

                            <?php $__errorArgs = ['mujer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mt-3">
                            <?php echo Form::label('area', 'Área:'); ?>

                            <?php echo Form::text('area', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el área que participará']); ?>

                            <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <div class="col-md-12 mt-3">
                            <?php echo Form::text('sembrando_id', $sembrando->id, ['class' => 'form-control','readonly' => 'true']); ?>

                            <?php $__errorArgs = ['sembrando_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                     
                            <?php echo Form::submit('Crear Beneficiado',['class' => 'btn btn-primary']); ?>


                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/sembrandos/crear.blade.php ENDPATH**/ ?>