

<?php $__env->startSection('contenido'); ?>

<?php if(session('info')): ?>
<div class="alert alert-success">
    <strong><?php echo e(session('info')); ?></strong>
</div>
<?php endif; ?>

<?php if(count($orquestas)): ?>
Esta Información se mostrara en el inicio
<?php $__currentLoopData = $orquestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orquestum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a type="submit" href="<?php echo e(route('admin.orquestas.edit',$orquestum)); ?>" class="btn btn-dark">Editar Orquesta</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
Crea aqui los datos de la Orquesta sinfonica
    <a type="submit" href="<?php echo e(route('admin.orquestas.create')); ?>" class="btn btn-dark">Crea Orquesta</a>
<?php endif; ?>
<br>
<br>
    

    <?php $__currentLoopData = $orquestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orquesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <img src="<?php echo e(asset($orquesta->image->url)); ?>" class="w-100" style="height:300px" alt="">
                </div>
                <div class="col-md-6">
                   <?php echo e($orquesta->descripcion); ?>

                    
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/orquestas/index.blade.php ENDPATH**/ ?>