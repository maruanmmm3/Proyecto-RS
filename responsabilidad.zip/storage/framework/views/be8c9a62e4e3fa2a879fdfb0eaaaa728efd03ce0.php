

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.volores')->html();
} elseif ($_instance->childHasBeenRendered('TRgnBFD')) {
    $componentId = $_instance->getRenderedChildComponentId('TRgnBFD');
    $componentTag = $_instance->getRenderedChildComponentTagName('TRgnBFD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TRgnBFD');
} else {
    $response = \Livewire\Livewire::mount('admin.volores');
    $html = $response->html();
    $_instance->logRenderedChild('TRgnBFD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/valors/index.blade.php ENDPATH**/ ?>