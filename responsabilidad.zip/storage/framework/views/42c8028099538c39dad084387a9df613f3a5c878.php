

<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-md-6">

            <?php if(session('info')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e(session('info')); ?></strong>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/libro.png')); ?>" class="img-thumbnail">
                        </div>
                        <div class="col-md-12 mt-2">

                            Brindar formación profesional técnica de calidad para jóvenes de Chimbote
                            <br>
                            <a href="<?php echo e(route('admin.promocions.create')); ?>" class="fa fa-plus-circle mt-2"> <i
                                    class="fa fa-plus-circle mt-2" style="font-size:2.4em" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                        <img src="<?php echo e(asset('images/compus.png')); ?>" class="img-thumbnail">
                </div>
            </div>
        </div>



        <?php $__currentLoopData = $promocions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-body p-5">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <img  src="<?php echo e(asset('images/logots.png')); ?>" >
                            </div>
                            <div class="col-md-12 mt-3">

                                <h1 class="text-center mt-2 text-uppercase"><?php echo e($promocion->nombre); ?></h1>
                            </div>

                      

                            <div class="d-flex justify-content-center mt-2 ">
                                <a class="btn btn-primary"
                                    href="<?php echo e(route('admin.carreras.vista', $promocion)); ?>">Observar</a>
                            </div>
                            <div class="d-flex justify-content-center mt-2 ml-3">
                                <a class="btn btn-success" href="<?php echo e(route('admin.promocions.edit', $promocion)); ?>">Editar</a>
                            </div>

                            <div class="d-flex justify-content-center mt-2 ml-3">
                                <form action="<?php echo e(route('admin.promocions.destroy', $promocion)); ?>" method="POST"
                                    class="formulario-eliminar">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">Eliminar</button>
                                </form>
                            </div>

                        

                        </div>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    
    <!--Local Stuff-->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            Swal.fire(
                'Eliminado!',
                'Tu archivo ha sido eliminado.',
                'success'
            )
        </script>
    <?php endif; ?>

    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡No podrás revertir esto!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, eliminar!'
            }).then((result) => {
                if (result.isConfirmed) {
                    /*  Swal.fire(
                         'Deleted!',
                         'Your file has been deleted.',
                         'success'
                     ) */
                    this.submit();
                }
            })
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/technicals/index.blade.php ENDPATH**/ ?>