

<?php $__env->startSection('contenido'); ?>

    <div class="d-flex justify-content-left mt-3">
        <a href="<?php echo e(route('admin.navidads.create')); ?>" class="btn btn-danger">Crear Campaña</a>
    </div>

    <div class="card mt-3">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-8 col-md-8 mt-3">

                    <img src="<?php echo e(asset('images/navidad.png')); ?>" alt="">

                </div>

                <div class="col-lg-4 col-md-4">

                        <img src="<?php echo e(asset('images/navidad2.jpg')); ?>" alt="">
                        <div style="position: absolute; bottom: 10px;left: 0; right: 0;opacity: 0.78"
                            class="d-flex justify-content-center">
                            <a href="<?php echo e(route('admin.navidads.index')); ?>" class="btn btn-danger">Campañas Navideñas</a>
                        </div>

                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/navidads/vista.blade.php ENDPATH**/ ?>