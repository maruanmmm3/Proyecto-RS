<div>
    <div class="card">

        


        <div class="card-header">
            <input wire:model="search" class="form-control" placeholder="Ingrese el nombre o correo del ususario">
        </div>

        <?php if($contactos->count()): ?>
            <div class="cart-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Telefono</th>
                            <th>Mensaje</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($mesaje->id); ?></td>
                                <td><?php echo e($mesaje->name); ?></td>
                                <td><?php echo e($mesaje->email); ?></td>
                                <td><?php echo e($mesaje->phone); ?></td>
                                <td><?php echo e($mesaje->message); ?></td>
                                <td width="10px">
                                    <form action="<?php echo e(route('admin.mensajes.destroy', $mesaje)); ?>" method="POST"  class="formulario-eliminar">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form> 
                                   
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div class="card-footer">
                <?php echo e($contactos->links()); ?>

            </div>
        <?php else: ?>

            <div class="card-body">
                <strong>No hay registros</strong>
            </div>

        <?php endif; ?>

    </div>

 
        
   
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <?php if(session('eliminar') == 'ok'): ?>
    <script>
         Swal.fire(
                'Eliminado!',
                'Tu archivo ha sido eliminado.',
                'success'
            )
    </script>
<?php endif; ?>

<script>
    $('.formulario-eliminar').submit(function(e){
        e.preventDefault();

        Swal.fire({
        title: '¿Estás seguro?',
        text: "¡No podrás revertir esto!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si, eliminar!'
    }).then((result) => {
        if (result.isConfirmed) {
           /*  Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            ) */
            this.submit();
        }
    }) 
    });


</script>


</div>





<?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/livewire/admin/mensaje.blade.php ENDPATH**/ ?>