

<?php $__env->startSection('contenido'); ?>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body text-center">
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('images/sembrando.jpg')); ?>" alt="">
                    </div>
                    <a href="<?php echo e(route('admin.sembrandos.create')); ?>"> <i class="fa fa-plus-circle mt-2" style="font-size:2.4em"
                    aria-hidden="true"></i></a>
                    <div class="col-md-4 mt-5">
                        <h3>Crear un proyecto</h3>
                    </div>
                    <br>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $sembrandos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sembrando): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('images/sembrando.jpg')); ?>" alt="">
                    </div>
                        <div class="col-md-6 my-auto">

                        <a href="<?php echo e(route('admin.sembrandos.crear', $sembrando)); ?>" ><button  value="Sembrando" class="btn btn-success" >
                                Crear Datos
                        </button></a>
                        <h6 class="mt-3">
                            <?php echo e($sembrando->nombre); ?>

                        </h6>
                     
                            <div class="form-group">
                                <div class="row">
                                    <form action="<?php echo e(route('admin.sembrandos.destroy', $sembrando)); ?>" class="formulario-eliminar" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                            <div class="col-md-2">
                                                <button type="submit" >
                                                    <i class="fa fa-trash mt-2" style="font-size:1.4em"  aria-hidden="true"></i>
                                                </button>
                                            </div>  
                                    </form> 

                                    <div class="col-md-2">
                                        <div class="col-md-2">
                                            <a href="<?php echo e(route('admin.sembrandos.edit', $sembrando)); ?>">
                                                <i class="fa fa-pencil-square-o mt-2" style="font-size:1.4em"  aria-hidden="true"></i>
                                           </a>
                                        </div>
                                    </div>  
                                    
                                    <div class="col-md-2">
                                            <div class="col-md-2">
                                                <a href="<?php echo e(route('admin.sembrandos.show', $sembrando)); ?>">
                                                    <i class="fa fa-eye mt-2" style="font-size:1.4em"  aria-hidden="true"></i>
                                               </a>
                                            </div>
                                    </div>  

                                    

                                </div>
                            </div>    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>
    <!--Local Stuff-->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('eliminar') == 'ok'): ?>
<script>
     Swal.fire(
            'Eliminado!',
            'Tu archivo ha sido eliminado.',
            'success'
        )
</script>
<?php endif; ?>

<script>
$('.formulario-eliminar').submit(function(e){
    e.preventDefault();

    Swal.fire({
    title: '¿Estás seguro?',
    text: "¡No podrás revertir esto!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Si, eliminar!'
}).then((result) => {
    if (result.isConfirmed) {
       /*  Swal.fire(
            'Deleted!',
            'Your file has been deleted.',
            'success'
        ) */
        this.submit();
    }
}) 
});


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/sembrandos/index.blade.php ENDPATH**/ ?>