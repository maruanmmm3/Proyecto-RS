

<?php $__env->startSection('contenido'); ?>
<div class="card">
    <div class="card-body">

        <?php echo Form::model($sembrando,['route' => ['admin.sembrandos.update', $sembrando], 'files' => true,'method' => 'put']); ?>


            <div class="form-group">
                <?php echo Form::label('SEMBRANDO VIDAS'); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('nombre', 'Nombre:'); ?>

                <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre del Proyecto Sembrando']); ?>


                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('descripcion', 'Descripción:'); ?>

                <?php echo Form::textArea('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la descripción del Proyecto Sembrando']); ?>


                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('fecha', 'Fecha:'); ?>

                <?php echo Form::date('fecha', null, ['class' => 'form-control']); ?>


                <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <?php echo Form::submit('Actualizar Proyecto Sembrando',['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/sembrandos/edit.blade.php ENDPATH**/ ?>