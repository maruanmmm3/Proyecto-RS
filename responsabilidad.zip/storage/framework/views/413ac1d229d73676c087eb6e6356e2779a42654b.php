

<?php $__env->startSection('contenido'); ?>
<div class="card">
    <div class="card-body">

        <?php echo Form::open(['route' => 'admin.proyectos.store', 'files' => true]); ?>

            <div class="form-group">
                <?php echo Form::label('nombre', 'Nombre:'); ?>

                <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre de el Proyecto']); ?>


                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('proposito', 'Proposito:'); ?>

                <?php echo Form::textArea('proposito', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el proposito de el Proyecto']); ?>


                <?php $__errorArgs = ['proposito'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="row mb-3">

               <div class="col">
                    <div class="image-wrapper">
                    <?php if(isset($proyecto->image)): ?>
                        <img id="picture" src="<?php echo e(Storage::url($proyecto->image->url)); ?>">
                    <?php else: ?>
                        <img id="picture" src="https://cdn.pixabay.com/photo/2015/07/17/22/43/student-849825_960_720.jpg" alt="">
                    <?php endif; ?>
                    </div>
                </div> 

                <div class="col">
                    <div class="form-group">
                        <?php echo Form::label('file', 'Imagen que se mostrara en el Proyecto'); ?>

                        <?php echo Form::file('file', ['class' => 'form-control-file', 'accept' => 'image/*']); ?>


                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <p>Aqui pondremos las indicaciones de la imagen </p>
                </div>

            </div>

            <?php echo Form::submit('Crear Proyecto',['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>


    </div>
</div>

<script>
    document.getElementById("file").addEventListener('change', cambiarImagen);
   
   function cambiarImagen(event){
       var file = event.target.files[0];
   
       var reader = new FileReader();
       reader.onload = (event) => {
           document.getElementById("picture").setAttribute('src', event.target.result); 
       };
   
       reader.readAsDataURL(file);
   }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/proyectos/create.blade.php ENDPATH**/ ?>