

<?php $__env->startSection('contenido'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
<?php $__currentLoopData = $navidads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="text-center color-gray">
                        <?php echo e($navidad->nombre); ?>

                    </div>
                    <div class="card-body">
                        <img src="<?php echo e(asset('images/gif.gif')); ?>" alt="">
                    </div>
                    <div class="card-body">
                        <a type="submit" href="<?php echo e(route('admin.navidads.show', $navidad)); ?>" class="btn btn-info text-white">Visualizar</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <a type="submit" href="" class="btn btn-danger text-white">Eliminar</a>
                    </div>                                    
                </div>
            </div>
                
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/navidads/index.blade.php ENDPATH**/ ?>