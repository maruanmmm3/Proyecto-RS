

<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="container" style="position: relative;">
                    <img src="<?php echo e(asset('images/navidad1.png')); ?>" style="height: 250px; width: 100%; object-fit: cover;" alt="">
                    <div 
                        class="d-flex justify-content-center mt-2">
                        <a type="submit" href="<?php echo e(route('admin.navidads.crear',$navidad)); ?>" class="btn btn-danger">Importar Datos</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="container" style="position: relative;">
                    <img src="<?php echo e(asset('images/navidad22.png')); ?>" style="height: 250px; width: 100%; object-fit: cover;" alt="">
                    <div 
                        class="d-flex justify-content-center mt-2">
                        <a type="submit" href="<?php echo e(route('admin.mavidads.mirar',$navidad)); ?>" class="btn btn-danger">Visualizar Datos</a>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <div class="col-lg-4 col-md-4">
        <div class="card">
            <div class="card-body">
                <div class="container" style="position: relative;">
                    <img src="<?php echo e(asset('images/navidad3.png')); ?>" alt="">
                    
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8 col-md-8">
        <div class="card">
            <div class="card-body">
                <div class="container" style="position: relative;">
                    <img src="<?php echo e(asset('images/navidad4.png')); ?>" alt="">
                  
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/navidads/show.blade.php ENDPATH**/ ?>