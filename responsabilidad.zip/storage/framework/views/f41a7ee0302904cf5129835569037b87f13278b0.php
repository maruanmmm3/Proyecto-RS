<div>
    <div class="card">

        <div class="card-header">
            <a class="btn btn-success" href="<?php echo e(route('admin.galerias.create')); ?>">Agregar Imagen</a>
        </div> 


       

        <?php if($galerias->count()): ?>
            <div class="cart-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Imagen</th>     
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galerium): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($galerium->id); ?></td>
                                <td> <img id="picture" width="300" src="<?php echo e(asset($galerium->image->url)); ?>"></td>
                                
                               
                                <td width="10px">
                                    <form action="<?php echo e(route('admin.galerias.destroy', $galerium)); ?>" method="POST" class="formulario-eliminar">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form> 
                                    <a href="<?php echo e(route('admin.galerias.edit', $galerium)); ?>"  class="btn btn-primary">
                                        Editar
                                    </a> 
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            
        <?php else: ?>

            <div class="card-body">
                <strong>No hay registros</strong>
            </div>

        <?php endif; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <?php if(session('eliminar') == 'ok'): ?>
    <script>
         Swal.fire(
                'Eliminado!',
                'Tu archivo ha sido eliminado.',
                'success'
            )
    </script>
<?php endif; ?>

<script>
    $('.formulario-eliminar').submit(function(e){
        e.preventDefault();

        Swal.fire({
        title: '¿Estás seguro?',
        text: "¡No podrás revertir esto!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si, eliminar!'
    }).then((result) => {
        if (result.isConfirmed) {
           /*  Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            ) */
            this.submit();
        }
    }) 
    });
</script>
</div>
<?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/livewire/admin/galerias.blade.php ENDPATH**/ ?>