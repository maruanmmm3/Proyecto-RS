

<?php $__env->startSection('contenido'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.proyectos')->html();
} elseif ($_instance->childHasBeenRendered('bLHesyH')) {
    $componentId = $_instance->getRenderedChildComponentId('bLHesyH');
    $componentTag = $_instance->getRenderedChildComponentTagName('bLHesyH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bLHesyH');
} else {
    $response = \Livewire\Livewire::mount('admin.proyectos');
    $html = $response->html();
    $_instance->logRenderedChild('bLHesyH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/proyectos/index.blade.php ENDPATH**/ ?>