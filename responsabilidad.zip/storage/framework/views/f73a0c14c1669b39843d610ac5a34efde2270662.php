

<?php $__env->startSection('contenido'); ?>

    <div class="card">
        <?php if($proyectos->count()): ?>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-4 col-md-6">
                        <div class="card">
                            <div class="text-center color-gray">
                                <?php echo e($proyecto->nombre); ?>

                            </div>
                            <div class="card-body">
                                <img src="<?php echo e(Storage::url($proyecto->image->url)); ?>" alt="">
                            </div>
                            <div class="row">
                                <div class="col-lg-4 col-md-6">
                                <a type="submit" href="<?php echo e(route('admin.proyectos.show', $proyecto)); ?>"
                                    class="btn btn-info text-white">Visualizar</a>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                <form action="<?php echo e(route('admin.proyectos.destroy', $proyecto)); ?>" method="POST"
                                    class="formulario-eliminar">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                </form>
                                </div>

                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <?php else: ?>
        <div class="card-body">
            <strong>No hay registros</strong>
        </div>
        <?php endif; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    
    <!--Local Stuff-->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('eliminar') == 'ok'): ?>
        <script>
             Swal.fire(
                    'Eliminado!',
                    'Tu archivo ha sido eliminado.',
                    'success'
                )
        </script>
    <?php endif; ?>

    <script>
        $('.formulario-eliminar').submit(function(e){
            e.preventDefault();

            Swal.fire({
            title: '¿Estás seguro?',
            text: "¡No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, eliminar!'
        }).then((result) => {
            if (result.isConfirmed) {
               /*  Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                ) */
                this.submit();
            }
        }) 
        });

   
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/proyectos/index.blade.php ENDPATH**/ ?>