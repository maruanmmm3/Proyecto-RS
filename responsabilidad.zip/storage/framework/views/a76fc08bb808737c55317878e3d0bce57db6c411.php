

<?php $__env->startSection('contenido'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.reconocimientos')->html();
} elseif ($_instance->childHasBeenRendered('0viCvuh')) {
    $componentId = $_instance->getRenderedChildComponentId('0viCvuh');
    $componentTag = $_instance->getRenderedChildComponentTagName('0viCvuh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0viCvuh');
} else {
    $response = \Livewire\Livewire::mount('admin.reconocimientos');
    $html = $response->html();
    $_instance->logRenderedChild('0viCvuh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/reconocimientos/index.blade.php ENDPATH**/ ?>