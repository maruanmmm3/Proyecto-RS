

<?php $__env->startSection('contenido'); ?>

<div class="row">
    <?php if($voluntarios->count()): ?>
    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body text-center d-flex align-items-center justify-content-center" style="height: 310px;">

                <div class="row">
                    <div class="col-12">
                        <h1 class="fw-bold"><?php echo e($horas); ?></h1>
                    </div>
                    <div class="col-12 mt-4">
                        <h1>Meta Horas</h1>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body text-center d-flex align-items-center justify-content-center" style="height: 310px;">

                <div class="row">
                    <div class="col-12">
                        <h1 class="fw-bold"></h1>
                    </div>
                    <div class="col-12 mt-4">
                        <h1>No hay Data</h1>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body">
        <a href="<?php echo e(route('admin.voluntarios.create')); ?>" class="btn btn-danger">Crear Voluntariado</a>
            </div>
        </div>
    </div>
</div>

    

    <div class="card">
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $voluntarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voluntario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-4 col-md-6">
                        <div class="card">
                            <div class="text-center color-gray">
                                
                            </div>
                            <div class="card-body">
                                <img src="<?php echo e(asset('images/voluntariado.jpg')); ?>" alt="">
                            </div>
                            <div class="card-body">
                                <a type="submit" href="<?php echo e(route('admin.voluntarios.show', $voluntario)); ?>"
                                    class="btn btn-info text-white">Visualizar</a>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <a type="submit" href="" class="btn btn-danger text-white">Eliminar</a>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/voluntarios/index.blade.php ENDPATH**/ ?>