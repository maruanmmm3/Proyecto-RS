

<?php $__env->startSection('contenido'); ?>

<div class="row">
    <?php if($voluntarios->count()): ?>
    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body text-center d-flex align-items-center justify-content-center" style="height: 310px;">

                <div class="row">
                    <div class="col-12">
                        <h1 class="fw-bold"><?php echo e($horas); ?></h1>
                    </div>
                    <div class="col-12 mt-4">
                        <h1>Meta Horas</h1>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body text-center d-flex align-items-center justify-content-center" style="height: 310px;">

                <div class="row">
                    <div class="col-12">
                        <h1 class="fw-bold"></h1>
                    </div>
                    <div class="col-12 mt-4">
                        <h1>No hay Data</h1>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="col-lg-6 col-md-6">
        <div class="card">
            <div class="card-body">
        <a href="<?php echo e(route('admin.voluntarios.create')); ?>" class="btn btn-danger">Crear Voluntariado</a>
            </div>
        </div>
    </div>
</div>

    

    <div class="card">
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $voluntarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voluntario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-4 col-md-6">
                        <div class="card">
                            <div class="text-center color-gray">
                                <?php echo e($voluntario->nombre); ?>

                            </div>
                            <div class="card-body">
                                <img src="<?php echo e(asset('images/voluntariado.jpg')); ?>" alt="">
                            </div>


                        <div class="row">

                            <div class="d-flex justify-content-center mt-2 ml-5">
                                <a class="btn btn-primary" href="<?php echo e(route('admin.voluntarios.show', $voluntario)); ?>"
                                class="btn btn-info text-white">Visualizar</a>
                            </div>

                            <div class="d-flex justify-content-center mt-2 ml-3">
                                <a class="btn btn-success" href="<?php echo e(route('admin.voluntarios.edit', $voluntario)); ?>">Editar</a>
                            </div>
                            
                            <div class="d-flex justify-content-center mt-2 ml-3">
                                 <form action="<?php echo e(route('admin.voluntarios.destroy', $voluntario)); ?>" method="POST"
                                    class="formulario-eliminar">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">Eliminar</button>
                                </form>
                            </div>

                        </div>

                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>


    <h2>Voluntarios</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Voluntario</th>
                  <th>Proyecto</th>
                  <th>Horas</th>
                  <th>fecha</th>
                </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $voluntarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voluntario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($voluntario->id); ?></td>
                  <td><?php echo e($voluntario->encargado); ?></td>
                  <td><?php echo e($voluntario->nombre); ?></td>
                  <td><?php echo e($voluntario->hora); ?></td>
                  <td><?php echo e($voluntario->fecha); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    
    <!--Local Stuff-->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            Swal.fire(
                'Eliminado!',
                'Tu archivo ha sido eliminado.',
                'success'
            )
        </script>
    <?php endif; ?>

    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡No podrás revertir esto!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, eliminar!'
            }).then((result) => {
                if (result.isConfirmed) {
                    /*  Swal.fire(
                         'Deleted!',
                         'Your file has been deleted.',
                         'success'
                     ) */
                    this.submit();
                }
            })
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/voluntarios/index.blade.php ENDPATH**/ ?>