

<?php $__env->startSection('contenido'); ?>
<div class="row">
    

        <?php if(session('info')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(session('info')); ?></strong>
            </div>
        <?php endif; ?>

        

        <div class="col-lg-3 col-md-3">
            <div class="card">
                <div class="w-100 d-flex justify-content-center">
                    <img src="<?php echo e(asset('images/frontend.png')); ?>" alt="">
                </div>
                <div class="card-body text-center vh-40">
                    <strong>Equipos de Gestion</strong>
                </div>
                <div class="w-100 d-flex justify-content-lg-end p-3">
                    <a href="<?php echo e(route('admin.equipos.index')); ?>" class="fa fa-eye icon-card" style="font-size:2.4em"></a> 
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-3">
            <div class="card">
                <div class="w-100 d-flex justify-content-center">
                    <img src="<?php echo e(asset('images/frontend.png')); ?>" alt="">
                </div>
                <div class="card-body text-center vh-40">
                    <strong>Valores de la Empresa</strong>
                </div>
                <div class="w-100 d-flex justify-content-lg-end p-3">   
                    <a href="<?php echo e(route('admin.valors.index')); ?>" class="fa fa-eye icon-card" style="font-size:2.4em"></a> 
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-3">
            <div class="card">
                <div class="w-100 d-flex justify-content-center">
                    <img src="<?php echo e(asset('images/frontend.png')); ?>" alt="">
                </div>
                <div class="card-body text-center vh-40">
                    <strong>Galeria de Imagenes</strong>
                </div>
                <div class="w-100 d-flex justify-content-lg-end p-3">   
                   <a href="<?php echo e(route('admin.galerias.index')); ?>" class="fa fa-eye icon-card" style="font-size:2.4em"></a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-3">
            <div class="card">
                <div class="w-100 d-flex justify-content-center">
                    <img src="<?php echo e(asset('images/frontend.png')); ?>" alt="">
                </div>
                <div class="card-body text-center vh-40">
                    <strong>Galeria de Imagenes Inferior</strong>
                </div>
                <div class="w-100 d-flex justify-content-lg-end p-3">   
                   <a href="<?php echo e(route('admin.fotos.index')); ?>" class="fa fa-eye icon-card" style="font-size:2.4em"></a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-3">
            <div class="card">
                <div class="w-100 d-flex justify-content-center">
                    <img src="<?php echo e(asset('images/frontend.png')); ?>" alt="">
                </div>
                <div class="card-body text-center vh-40">
                    <strong>Proyectos fron</strong>
                </div>
                <div class="w-100 d-flex justify-content-lg-end p-3">   
                   <a href="<?php echo e(route('admin.proyectos.index')); ?>" class="fa fa-eye icon-card" style="font-size:2.4em"></a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-3">
            <div class="card">
                <div class="w-100 d-flex justify-content-center">
                    <img src="<?php echo e(asset('images/frontend.png')); ?>" alt="">
                </div>
                <div class="card-body text-center vh-40">
                    <strong>Reconocimientos Nosotros</strong>
                </div>
                <div class="w-100 d-flex justify-content-lg-end p-3">   
                   <a href="<?php echo e(route('admin.reconocimientos.index')); ?>" class="fa fa-eye icon-card" style="font-size:2.4em"></a>
                </div>
            </div>
        </div>

       
        
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/equipos/vista.blade.php ENDPATH**/ ?>