

<?php $__env->startSection('contenido'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.galerias')->html();
} elseif ($_instance->childHasBeenRendered('c5zgOzP')) {
    $componentId = $_instance->getRenderedChildComponentId('c5zgOzP');
    $componentTag = $_instance->getRenderedChildComponentTagName('c5zgOzP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('c5zgOzP');
} else {
    $response = \Livewire\Livewire::mount('admin.galerias');
    $html = $response->html();
    $_instance->logRenderedChild('c5zgOzP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/galerias/index.blade.php ENDPATH**/ ?>