

<?php $__env->startSection('contenido'); ?>
<div class="card">
    <div class="card-body">

        <?php echo Form::open(['route' => 'admin.reconocimientos.store', 'files' => true]); ?>


        <div class="form-group">
            <?php echo Form::label('nombre', 'Introduce el Nombre:'); ?>

            <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre del Reconocimiento']); ?>


            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>    
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('descripcion', 'Introduce la Descripción:'); ?>

            <?php echo Form::textArea('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la Descripción del Reconocimiento']); ?>


            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>    
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

            <div class="row mb-3">

               <div class="col">
                    <div class="image-wrapper">
                    <?php if(isset($reconocimientos->image)): ?>
                        <img id="picture" src="<?php echo e(Storage::url($reconocimientos->image->url)); ?>">
                    <?php else: ?>
                        <img id="picture" src="https://cdn.pixabay.com/photo/2018/03/03/20/02/laptop-3196481_960_720.jpg" alt="">
                    <?php endif; ?>
                    </div>
                </div> 

                <div class="col">
                    <div class="form-group">
                        <?php echo Form::label('file', 'Imagen que se mostrara en el Front'); ?>

                        <?php echo Form::file('file', ['class' => 'form-control-file', 'accept' => 'image/*']); ?>


                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <p>Aqui pondremos las indicaciones de la imagen </p>
                </div>

            </div>

            <?php echo Form::submit('Crear Reconocimiento',['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>


    </div>
</div>

<script>
    document.getElementById("file").addEventListener('change', cambiarImagen);
   
   function cambiarImagen(event){
       var file = event.target.files[0];
   
       var reader = new FileReader();
       reader.onload = (event) => {
           document.getElementById("picture").setAttribute('src', event.target.result); 
       };
   
       reader.readAsDataURL(file);
   }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/reconocimientos/create.blade.php ENDPATH**/ ?>