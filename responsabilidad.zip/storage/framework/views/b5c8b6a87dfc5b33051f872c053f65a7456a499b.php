

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.mensaje')->html();
} elseif ($_instance->childHasBeenRendered('xjVLSsv')) {
    $componentId = $_instance->getRenderedChildComponentId('xjVLSsv');
    $componentTag = $_instance->getRenderedChildComponentTagName('xjVLSsv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xjVLSsv');
} else {
    $response = \Livewire\Livewire::mount('admin.mensaje');
    $html = $response->html();
    $_instance->logRenderedChild('xjVLSsv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/mensajes/index.blade.php ENDPATH**/ ?>