

<?php $__env->startSection('contenido'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.fotos')->html();
} elseif ($_instance->childHasBeenRendered('kCb1s1H')) {
    $componentId = $_instance->getRenderedChildComponentId('kCb1s1H');
    $componentTag = $_instance->getRenderedChildComponentTagName('kCb1s1H');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kCb1s1H');
} else {
    $response = \Livewire\Livewire::mount('admin.fotos');
    $html = $response->html();
    $_instance->logRenderedChild('kCb1s1H', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\responsabilidad\resources\views/admin/fotos/index.blade.php ENDPATH**/ ?>