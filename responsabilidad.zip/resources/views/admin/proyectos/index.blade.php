@extends('layouts.app')

@section('contenido')
    @livewire('admin.proyectos')
@endsection
