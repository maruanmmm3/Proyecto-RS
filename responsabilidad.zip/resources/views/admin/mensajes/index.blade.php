@extends('layouts.app')

@section('contenido')

    @livewire('admin.mensaje')


@endsection