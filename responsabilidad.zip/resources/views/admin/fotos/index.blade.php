@extends('layouts.app')

@section('contenido')
    @livewire('admin.fotos')
@endsection