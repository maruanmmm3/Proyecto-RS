@extends('layouts.app')

@section('contenido')
    @livewire('admin.grupo')
@endsection