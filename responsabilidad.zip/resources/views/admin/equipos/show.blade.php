@extends('layouts.app')

@section('contenido')
    referencia exitosa
@endsection