@extends('layouts.app')

@section('contenido')
    @livewire('admin.galerias')
@endsection