@extends('layouts.app')

@section('contenido')

    @livewire('admin.volores')

@endsection