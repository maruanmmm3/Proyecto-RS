@extends('layouts.app')

@section('contenido')
@livewire('admin.reconocimientos')
@endsection