<!DOCTYPE html>
<html class="wide wow-animation" lang="en">

<head>
  <title>About</title>
  <meta name="format-detection" content="telephone=no">
  <meta name="viewport"
    content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta charset="utf-8">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">
  <!-- Stylesheets-->
  <link rel="stylesheet" type="text/css"
    href="//fonts.googleapis.com/css?family=Montserrat:400,500,600,700%7CPoppins:400%7CTeko:300,400">
    <link rel="stylesheet" href="{{asset('inicios/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('inicios/css/fonts.css')}}">
    <link rel="stylesheet" href="{{asset('inicios/css/style.css')}}">
  <style>
    .ie-panel {
      display: none;
      background: #212121;
      padding: 10px 0;
      box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
      clear: both;
      text-align: center;
      position: relative;
      z-index: 1;
    }

    html.ie-10 .ie-panel,
    html.lt-ie-10 .ie-panel {
      display: block;
    }
  </style>
</head>

<body>
  <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img
        src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820"
        alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a>
  </div>
  <div class="preloader">
    <div class="preloader-body">
      <div class="cssload-container">
        <div class="cssload-speeding-wheel"></div>
      </div>
      <p>Loading...</p>
    </div>
  </div>
  <div class="page">
    <!-- Page Header-->
    <!-- <a class="banner banner-top" href="https://www.templatemonster.com/intense-multipurpose-html-template.html" target="_blank"><img src="images/intense_02.jpg" alt=""/></a> -->
    <header class="section page-header">
      <!-- RD Navbar-->
      <div class="rd-navbar-wrap">
        <nav class="rd-navbar rd-navbar-corporate" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed"
          data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static"
          data-lg-device-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static"
          data-xl-device-layout="rd-navbar-static" data-xxl-layout="rd-navbar-static"
          data-xxl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px"
          data-xxl-stick-up-offset="106px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
          <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse">
            <span></span>
          </div>
          <div class="rd-navbar-aside-outer">
            <div class="rd-navbar-aside">
              <!-- RD Navbar Panel-->
              <div class="rd-navbar-panel">
                <!-- RD Navbar Toggle-->
                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                <!-- RD Navbar Brand-->
                <div class="rd-navbar-brand">
                  <!--Brand--><a class="brand" href="index.html"><img src="images/sider.png" alt="" width="225"
                      height="18" /></a>
                </div>
              </div>
              <div class="rd-navbar-aside-right rd-navbar-collapse">
                <ul class="rd-navbar-corporate-contacts">
                  <li>
                    <div class="unit unit-spacing-xs">
                      <div class="unit-left"><span class="icon fa fa-clock-o"></span></div>
                      <div class="unit-body">
                        <p>09:00<span>am</span> — 05:00<span>pm</span></p>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="unit unit-spacing-xs">
                      <div class="unit-left"><span class="icon fa fa-phone"></span></div>
                      <div class="unit-body"><a class="link-phone" href="tel:#">+51 943529504</a></div>
                    </div>
                  </li>
                  <li>
                    <div class="unit unit-spacing-xs">

                        @if (Route::has('login'))
                        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                            @auth
                                <a href="{{ url('/dashboard') }}" class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a>
                            @else
                                <a href="{{ route('login') }}" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>
        
                                @if (Route::has('register'))
                                    <a href="{{ route('register') }}" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                                @endif
                            @endauth
                        </div>
                    @endif
                      {{-- <div class="unit-left"><span class="icon fa fa-phone"></span></div>
                      <div class="unit-body"><a class="link-phone" href="tel:#">+51 943529504</a></div> --}}
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="rd-navbar-main-outer">
            <div class="rd-navbar-main">
              <div class="rd-navbar-nav-wrap">
                <ul class="list-inline list-inline-md rd-navbar-corporate-list-social">
                  <li><a class="icon fa fa-facebook" href="#"></a></li>
                  <li><a class="icon fa fa-twitter" href="#"></a></li>
                  <li><a class="icon fa fa-google-plus" href="#"></a></li>
                  <li><a class="icon fa fa-instagram" href="#"></a></li>
                </ul>
                <!-- RD Navbar Nav-->
                <ul class="rd-navbar-nav">
                  <li class="rd-nav-item"><a class="rd-nav-link" href="{{route('inicios.index')}}">Inicio</a>
                  </li>
                  <li class="rd-nav-item active"><a class="rd-nav-link" href="{{route('inicios.nosotro')}}">Nosotros</a>
                  </li>
                  <!--   <li class="rd-nav-item"><a class="rd-nav-link" href="typography.html">Typography</a>
                  </li> -->
                  <li class="rd-nav-item"><a class="rd-nav-link" href="{{route('inicios.contactano')}}">Contactanos</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- Breadcrumbs -->
    <section class="breadcrumbs-custom-inset">
      <div class="breadcrumbs-custom context-dark bg-overlay-60">
        <div class="container">
          <h2 class="breadcrumbs-custom-title">About</h2>
          <ul class="breadcrumbs-custom-path">
            <li><a href="index.html">Home</a></li>
            <li class="active">About</li>
          </ul>
        </div>
        <div class="box-position" style="background-image: url(images/breadcrumbs-bg.jpg);"></div>
      </div>
    </section>
    <!-- Why choose us-->
    <section class="section section-sm section-first bg-default text-md-left">
      <div class="container">
        <div class="row row-50 justify-content-center align-items-xl-center">
          <div class="col-md-10 col-lg-5 col-xl-6"><img src="images/about-1-519x564.jpg" alt="" width="519"
              height="564" />
          </div>
          <div class="col-md-10 col-lg-7 col-xl-6">
            <h1 class="text-spacing-25 font-weight-normal title-opacity-9">Porque elegirnos</h1>
            <!-- Bootstrap tabs-->
            <div class="tabs-custom tabs-horizontal tabs-line" id="tabs-4">
              <!-- Nav tabs-->
              <ul class="nav nav-tabs">
                <li class="nav-item" role="presentation"><a class="nav-link" href="#tabs-4-2"
                    data-toggle="tab">Skills</a></li>
              </ul>
              <!-- Tab panes-->
              <div class="tab-content">
                <div class="tab-pane fade" id="tabs-4-2">
                  <div class="row row-40 justify-content-center text-center inset-top-10">
                    <div class="col-sm-4">
                      <!-- Circle Progress Bar-->
                      <div class="progress-bar-circle" data-value="0.87" data-gradient="#01b3a7"
                        data-empty-fill="transparent" data-size="150" data-thickness="12" data-reverse="true">
                        <span></span>
                      </div>
                      <p class="progress-bar-circle-title">Tours</p>
                    </div>
                    <div class="col-sm-4">
                      <!-- Circle Progress Bar-->
                      <div class="progress-bar-circle" data-value="0.74" data-gradient="#01b3a7"
                        data-empty-fill="transparent" data-size="150" data-thickness="12" data-reverse="true">
                        <span></span>
                      </div>
                      <p class="progress-bar-circle-title">Excursions</p>
                    </div>
                    <div class="col-sm-4">
                      <!-- Circle Progress Bar-->
                      <div class="progress-bar-circle" data-value="0.99" data-gradient="#01b3a7"
                        data-empty-fill="transparent" data-size="150" data-thickness="12" data-reverse="true">
                        <span></span>
                      </div>
                      <p class="progress-bar-circle-title">Hotel Bookings</p>
                    </div>
                  </div>
                  <div class="group-md group-middle"><a class="button button-width-xl-230 button-primary button-pipaluk"
                      href="#">Get in touch</a><a class="button button-black-outline button-width-xl-230" href="#">Read
                      more</a></div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Latest Projects-->
    <section class="section section-sm section-fluid bg-default">
      <div class="container">
        <h3>Destinations</h3>
      </div>
      <!-- Owl Carousel-->
      <div class="owl-carousel owl-classic owl-timeline" data-items="1" data-md-items="2" data-lg-items="3"
        data-xl-items="4" data-margin="30" data-autoplay="false" data-nav="true" data-dots="true">
        <div class="owl-item">
          <!-- Thumbnail Classic-->
          <article class="thumbnail thumbnail-mary">
            <div class="thumbnail-mary-figure"><img src="images/gallery-image-11-420x308.jpg" alt="" width="420"
                height="308" />
            </div>
            <div class="thumbnail-mary-caption"><a class="icon fl-bigmug-line-zoom60"
                href="images/gallery-image-11-1200x800-original.jpg" data-lightgallery="item"><img
                  src="images/gallery-image-11-420x308.jpg" alt="" width="420" height="308" /></a>
            </div>
          </article>
          <div class="thumbnail-mary-description">
            <h5 class="thumbnail-mary-project"><a href="#">France</a></h5><span class="thumbnail-mary-decor"></span>
            <h5 class="thumbnail-mary-time">
            </h5>
          </div>
        </div>
        <div class="owl-item">
          <!-- Thumbnail Classic-->
          <article class="thumbnail thumbnail-mary">
            <div class="thumbnail-mary-figure"><img src="images/gallery-image-12-420x308.jpg" alt="" width="420"
                height="308" />
            </div>
            <div class="thumbnail-mary-caption"><a class="icon fl-bigmug-line-zoom60"
                href="images/gallery-image-12-1200x800-original.jpg" data-lightgallery="item"><img
                  src="images/gallery-image-12-420x308.jpg" alt="" width="420" height="308" /></a>
            </div>
          </article>
          <div class="thumbnail-mary-description">
            <h5 class="thumbnail-mary-project"><a href="#">Italy</a></h5><span class="thumbnail-mary-decor"></span>
            <h5 class="thumbnail-mary-time">
            </h5>
          </div>
        </div>
        <div class="owl-item">
          <!-- Thumbnail Classic-->
          <article class="thumbnail thumbnail-mary">
            <div class="thumbnail-mary-figure"><img src="images/gallery-image-13-420x308.jpg" alt="" width="420"
                height="308" />
            </div>
            <div class="thumbnail-mary-caption"><a class="icon fl-bigmug-line-zoom60"
                href="images/gallery-image-13-1200x800-original.jpg" data-lightgallery="item"><img
                  src="images/gallery-image-13-420x308.jpg" alt="" width="420" height="308" /></a>
            </div>
          </article>
          <div class="thumbnail-mary-description">
            <h5 class="thumbnail-mary-project"><a href="#">Egypt</a></h5><span class="thumbnail-mary-decor"></span>
            <h5 class="thumbnail-mary-time">
            </h5>
          </div>
        </div>
        <div class="owl-item">
          <!-- Thumbnail Classic-->
          <article class="thumbnail thumbnail-mary">
            <div class="thumbnail-mary-figure"><img src="images/gallery-image-14-420x308.jpg" alt="" width="420"
                height="308" />
            </div>
            <div class="thumbnail-mary-caption"><a class="icon fl-bigmug-line-zoom60"
                href="images/gallery-image-14-1200x800-original.jpg" data-lightgallery="item"><img
                  src="images/gallery-image-14-420x308.jpg" alt="" width="420" height="308" /></a>
            </div>
          </article>
          <div class="thumbnail-mary-description">
            <h5 class="thumbnail-mary-project"><a href="#">Dubai</a></h5><span class="thumbnail-mary-decor"></span>
            <h5 class="thumbnail-mary-time">
            </h5>
          </div>
        </div>
        <div class="owl-item">
          <!-- Thumbnail Classic-->
          <article class="thumbnail thumbnail-mary">
            <div class="thumbnail-mary-figure"><img src="images/gallery-image-15-420x308.jpg" alt="" width="420"
                height="308" />
            </div>
            <div class="thumbnail-mary-caption"><a class="icon fl-bigmug-line-zoom60"
                href="images/gallery-image-15-1200x800-original.jpg" data-lightgallery="item"><img
                  src="images/gallery-image-15-420x308.jpg" alt="" width="420" height="308" /></a>
            </div>
          </article>
          <div class="thumbnail-mary-description">
            <h5 class="thumbnail-mary-project"><a href="#">Spain</a></h5><span class="thumbnail-mary-decor"></span>
            <h5 class="thumbnail-mary-time">
            </h5>
          </div>
        </div>
        <div class="owl-item">
          <!-- Thumbnail Classic-->
          <article class="thumbnail thumbnail-mary">
            <div class="thumbnail-mary-figure"><img src="images/gallery-image-16-420x308.jpg" alt="" width="420"
                height="308" />
            </div>
            <div class="thumbnail-mary-caption"><a class="icon fl-bigmug-line-zoom60"
                href="images/gallery-image-16-1200x800-original.jpg" data-lightgallery="item"><img
                  src="images/gallery-image-16-420x308.jpg" alt="" width="420" height="308" /></a>
            </div>
          </article>
          <div class="thumbnail-mary-description">
            <h5 class="thumbnail-mary-project"><a href="#">Africa</a></h5><span class="thumbnail-mary-decor"></span>
            <h5 class="thumbnail-mary-time">
            </h5>
          </div>
        </div>
      </div>
    </section>
    <!-- What people Say-->
    <section class="section section-sm section-last bg-default">
      <div class="container">
        <h3>What People Say</h3>
        <!-- Owl Carousel-->
        <div class="owl-carousel owl-modern" data-items="1" data-stage-padding="15" data-margin="30" data-dots="true"
          data-animation-in="fadeIn" data-animation-out="fadeOut" data-autoplay="true">
          <!-- Quote Lisa-->
          <article class="quote-lisa">
            <div class="quote-lisa-body"><a class="quote-lisa-figure" href="#"><img class="img-circles"
                  src="images/user-16-100x100.jpg" alt="" width="100" height="100" /></a>
              <div class="quote-lisa-text">
                <p class="q">Pharetra vel turpis nunc eget lorem dolor sed viverra ipsum. Diam phasellus vestibulum
                  lorem sed risus ultricies. Aenean et tortor at risus viverra adipiscing. Aliquet enim tortor at auctor
                  urna. Tortor aliquam nulla facilisi cras fermentum. Malesuada pellentesque elit eget gravida cum
                  sociis natoque.</p>
              </div>
              <h5 class="quote-lisa-cite"><a href="#">Catherine Williams</a></h5>
              <p class="quote-lisa-status">Regular Client</p>
            </div>
          </article>
          <!-- Quote Lisa-->
          <article class="quote-lisa">
            <div class="quote-lisa-body"><a class="quote-lisa-figure" href="#"><img class="img-circles"
                  src="images/user-17-100x100.jpg" alt="" width="100" height="100" /></a>
              <div class="quote-lisa-text">
                <p class="q">Sodales ut etiam sit amet nisl purus. Maecenas accumsan lacus vel facilisis volutpat est.
                  Suscipit adipiscing bibendum est ultricies integer quis auctor. Viverra aliquet eget sit amet tellus
                  cras adipiscing. Posuere ac ut consequat semper viverra nam libero justo laoreet. Iaculis eu non diam
                  phasellus vestibulum lorem sed risus ultricies.</p>
              </div>
              <h5 class="quote-lisa-cite"><a href="#">Rupert Wood</a></h5>
              <p class="quote-lisa-status">Regular Client</p>
            </div>
          </article>
          <!-- Quote Lisa-->
          <article class="quote-lisa">
            <div class="quote-lisa-body"><a class="quote-lisa-figure" href="#"><img class="img-circles"
                  src="images/user-18-100x100.jpg" alt="" width="100" height="100" /></a>
              <div class="quote-lisa-text">
                <p class="q">Lacus vestibulum sed arcu non odio euismod lacinia. Pellentesque elit ullamcorper dignissim
                  cras. Ultrices eros in cursus turpis massa tincidunt dui. Nunc pulvinar sapien et ligula ullamcorper
                  malesuada proin. Commodo odio aenean sed adipiscing diam. Sed euismod nisi porta lorem mollis aliquam.
                </p>
              </div>
              <h5 class="quote-lisa-cite"><a href="#">Samantha Brown</a></h5>
              <p class="quote-lisa-status">Regular Client</p>
            </div>
          </article>
        </div>
      </div>
    </section>
    <!--Counters-->
    <!-- Counter Classic-->
    <section class="section section-fluid bg-default">
      <div class="parallax-container" data-parallax-img="images/bg-counter-2.jpg">
        <div class="parallax-content section-xl context-dark bg-overlay-26">
          <div class="container">
            <div class="row row-50 justify-content-center border-classic">
              <div class="col-sm-6 col-md-5 col-lg-3">
                <div class="counter-classic">
                  <div class="counter-classic-number"><span class="counter">12</span>
                  </div>
                  <h5 class="counter-classic-title">Awards</h5>
                </div>
              </div>
              <div class="col-sm-6 col-md-5 col-lg-3">
                <div class="counter-classic">
                  <div class="counter-classic-number"><span class="counter">194</span>
                  </div>
                  <h5 class="counter-classic-title">Tours</h5>
                </div>
              </div>
              <div class="col-sm-6 col-md-5 col-lg-3">
                <div class="counter-classic">
                  <div class="counter-classic-number"><span class="counter">2</span><span class="symbol">k</span>
                  </div>
                  <h5 class="counter-classic-title">Travelers</h5>
                </div>
              </div>
              <div class="col-sm-6 col-md-5 col-lg-3">
                <div class="counter-classic">
                  <div class="counter-classic-number"><span class="counter">25</span>
                  </div>
                  <h5 class="counter-classic-title">Team members</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Page Footer-->
    <footer class="section footer-corporate context-dark">
      <div class="footer-corporate-inset">
        <div class="container">
          <div class="row row-40 justify-content-lg-between">
            <div class="col-sm-6 col-md-12 col-lg-3 col-xl-4">
              <div class="oh-desktop">
                <div class="wow slideInRight" data-wow-delay="0s">
                  <h6 class="text-spacing-100 text-uppercase">Contactanos</h6>
                  <ul class="footer-contacts d-inline-block d-sm-block">
                    <li>
                      <div class="unit">
                        <div class="unit-left"><span class="icon fa fa-phone"></span></div>
                        <div class="unit-body"><a class="link-phone" href="tel:#">+51 943-750-857</a></div>
                      </div>
                    </li>
                    <li>
                      <div class="unit">
                        <div class="unit-left"><span class="icon fa fa-envelope"></span></div>
                        <div class="unit-body"><a class="link-aemail" href="mailto:#">jorge.castillo@sider.com.pe</a>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="unit">
                        <div class="unit-left"><span class="icon fa fa-location-arrow"></span></div>
                        <div class="unit-body"><a class="link-location" href="#">AV. SANTIAG ANTUNEZ DE MAYOLO NRO. S/N
                            Z.I. ZONA INDUSTRIAL</a></div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-5 col-lg-3 col-xl-4">
              <div class="oh-desktop">
                <div class="wow slideInDown" data-wow-delay="0s">
                  <h6 class="text-spacing-100 text-uppercase">Popular news</h6>
                  <!-- Post Minimal 2-->
                  <article class="post post-minimal-2">
                    <p class="post-minimal-2-title"><a href="#">Your Personal Guide to 5 Best Places to Visit on
                        Earth</a></p>
                    <div class="post-minimal-2-time">
                      <time datetime="2019-05-04">May 04, 2019</time>
                    </div>
                  </article>
                  <!-- Post Minimal 2-->
                  <article class="post post-minimal-2">
                    <p class="post-minimal-2-title"><a href="#">Top 10 Hotels: Rating by Wonder Tour Travel Experts</a>
                    </p>
                    <div class="post-minimal-2-time">
                      <time datetime="2019-05-04">May 04, 2019</time>
                    </div>
                  </article>
                </div>
              </div>
            </div>
            <div class="col-sm-11 col-md-7 col-lg-5 col-xl-4">
              <div class="oh-desktop">
                <div class="wow slideInLeft" data-wow-delay="0s">
                  <h6 class="text-spacing-100 text-uppercase">Enlace Rapido </h6>
                  <ul class="row-6 list-0 list-marked list-marked-md list-marked-secondary list-custom-2">
                    <li><a href="about.html">About us</a></li>
                    <li><a href="#">Our Tours</a></li>
                    <li><a href="#">Our Team</a></li>
                    <li><a href="#">Gallery</a></li>
                    <li><a href="#">Blog</a></li>
                  </ul>
                  <div class="group-md group-middle justify-content-sm-start"><a
                      class="button button-lg button-primary button-ujarak" href="#">Get in touch</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-corporate-bottom-panel">
        <div class="container">
          <div class="row justfy-content-xl-space-berween row-10 align-items-md-center2">
            <div class="col-sm-6 col-md-4 text-sm-right text-md-center">
              <div>
                <ul class="list-inline list-inline-sm footer-social-list-2">
                  <li><a class="icon fa fa-facebook" href="#"></a></li>
                  <li><a class="icon fa fa-twitter" href="#"></a></li>
                  <li><a class="icon fa fa-google-plus" href="#"></a></li>
                  <li><a class="icon fa fa-instagram" href="#"></a></li>
                </ul>
              </div>
            </div>
            <div class="col-sm-6 col-md-4 order-sm-first">
              <!-- Rights-->
              <p class="rights"><span>&copy;&nbsp;</span><span
                  class="copyright-year"></span><span>&nbsp;</span><span>Wonder
                  Tour</span>. All Rights Reserved. Design
                by <a href="https://www.templatemonster.com">TemplateMonster</a></p>
            </div>
            <div class="col-sm-6 col-md-4 text-md-right">
              <p class="rights"><a href="#">Privacy Policy</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
  <!-- Global Mailform Output-->
  <div class="snackbars" id="form-output-global"></div>
  <!-- Javascript-->
  <script src="{{asset('inicios/js/core.min.js')}}"></script>
  <script src="{{asset('inicios/js/script.js')}}"></script>
</body>

</html>