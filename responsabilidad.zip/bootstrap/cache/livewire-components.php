<?php return array (
  'admin.fotos' => 'App\\Http\\Livewire\\Admin\\Fotos',
  'admin.galerias' => 'App\\Http\\Livewire\\Admin\\Galerias',
  'admin.grupo' => 'App\\Http\\Livewire\\Admin\\Grupo',
  'admin.mensaje' => 'App\\Http\\Livewire\\Admin\\Mensaje',
  'admin.proyectos' => 'App\\Http\\Livewire\\Admin\\Proyectos',
  'admin.reconocimientos' => 'App\\Http\\Livewire\\Admin\\Reconocimientos',
  'admin.volores' => 'App\\Http\\Livewire\\Admin\\Volores',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);