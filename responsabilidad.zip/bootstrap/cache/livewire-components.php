<?php return array (
  'admin.mensaje' => 'App\\Http\\Livewire\\Admin\\Mensaje',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);